---
name: Guardian Shield
colors:
  surface: '#f8f9ff'
  surface-dim: '#cbdbf5'
  surface-bright: '#f8f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#eff4ff'
  surface-container: '#e5eeff'
  surface-container-high: '#dce9ff'
  surface-container-highest: '#d3e4fe'
  on-surface: '#0b1c30'
  on-surface-variant: '#41484b'
  inverse-surface: '#213145'
  inverse-on-surface: '#eaf1ff'
  outline: '#71787c'
  outline-variant: '#c1c7cc'
  surface-tint: '#376476'
  primary: '#003747'
  on-primary: '#ffffff'
  primary-container: '#1e4e5f'
  on-primary-container: '#91bed2'
  inverse-primary: '#a0cde1'
  secondary: '#416279'
  on-secondary: '#ffffff'
  secondary-container: '#c2e4ff'
  on-secondary-container: '#45667d'
  tertiary: '#22343d'
  on-tertiary: '#ffffff'
  tertiary-container: '#384b54'
  on-tertiary-container: '#a6bac5'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#bbe9fe'
  primary-fixed-dim: '#a0cde1'
  on-primary-fixed: '#001f29'
  on-primary-fixed-variant: '#1c4c5d'
  secondary-fixed: '#c8e6ff'
  secondary-fixed-dim: '#a9cbe5'
  on-secondary-fixed: '#001e2e'
  on-secondary-fixed-variant: '#284a60'
  tertiary-fixed: '#d1e6f0'
  tertiary-fixed-dim: '#b5cad4'
  on-tertiary-fixed: '#0a1e26'
  on-tertiary-fixed-variant: '#374952'
  background: '#f8f9ff'
  on-background: '#0b1c30'
  surface-variant: '#d3e4fe'
typography:
  headline-xl:
    fontFamily: Inter
    fontSize: 2.25rem
    fontWeight: '600'
    lineHeight: 2.75rem
    letterSpacing: -0.025em
  headline-xl-mobile:
    fontFamily: Inter
    fontSize: 1.75rem
    fontWeight: '600'
    lineHeight: 2.25rem
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Inter
    fontSize: 1.5rem
    fontWeight: '600'
    lineHeight: 2rem
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Inter
    fontSize: 1.25rem
    fontWeight: '600'
    lineHeight: 1.75rem
    letterSpacing: -0.015em
  headline-sm:
    fontFamily: Inter
    fontSize: 1rem
    fontWeight: '600'
    lineHeight: 1.5rem
    letterSpacing: -0.01em
  body-lg:
    fontFamily: Inter
    fontSize: 1.125rem
    fontWeight: '400'
    lineHeight: 1.75rem
    letterSpacing: '0'
  body-md:
    fontFamily: Inter
    fontSize: 0.9375rem
    fontWeight: '400'
    lineHeight: 1.5rem
    letterSpacing: '0'
  body-sm:
    fontFamily: Inter
    fontSize: 0.8125rem
    fontWeight: '400'
    lineHeight: 1.25rem
    letterSpacing: '0'
  label-md:
    fontFamily: Inter
    fontSize: 0.875rem
    fontWeight: '500'
    lineHeight: 1.25rem
    letterSpacing: 0.01em
  label-sm:
    fontFamily: Inter
    fontSize: 0.75rem
    fontWeight: '600'
    lineHeight: 1rem
    letterSpacing: 0.04em
  mono-data:
    fontFamily: Inter
    fontSize: 0.8125rem
    fontWeight: '500'
    lineHeight: 1.25rem
    letterSpacing: -0.01em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 1.25rem
  gutter-mobile: 0.75rem
  margin: 2rem
  margin-mobile: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
---

## Brand & Style

This design system establishes an atmosphere of quiet competence, clinical reassurance, and editorial restraint for parents overseeing their children's digital environments. The design avoids aggressive alertism, tech-fetishism, neon accents, and patronizing playful motifs. Instead, it prioritizes legibility, scannable data density, and emotional equilibrium.

### Design Principles
- **Reassuring Composure:** Digital safety interfaces often induce anxiety. This system delivers critical telemetry with measured calm, ensuring parents feel in control rather than overwhelmed.
- **Editorial Legibility:** Layouts follow structured editorial conventions: deliberate hierarchy, clear typographic anchors, and structured tabular clarity over decorative illustrations.
- **Functional Integrity:** Visual signals are reserved entirely for systemic status. Red and amber are strictly reserved for genuine safety risks, avoiding cosmetic misdirection.
- **Modern Utilitarianism:** Form factors rely on disciplined grid boundaries, subtle structural separation via hairline borders, and micro-elevation rather than heavy drop shadows or gratuitous blurs.

## Colors

The palette is rooted in deep slate teal, warm-neutral foundations, and muted functional semaphores. Contrast ratios across text and interactive surfaces strictly meet or exceed WCAG 2.1 AA standards.

### Core Palettes
- **Primary (`#1E4E5F`):** Deep slate teal representing stability and institutional trust. Used for primary controls, active navigation markers, and anchor points.
- **Secondary (`#4A6B82`):** Balanced mid-slate blue for secondary actions, supporting metadata, and contextual filters.
- **Neutral Surface Palette:**
  - Canvas Background: `#F8F9FA` (Warm canvas foundation)
  - Surface Default: `#FFFFFF` (Card and panel backgrounds)
  - Surface Muted: `#F1F5F9` (Data strips, table headers, inactive tracks)
  - Border Hairline: `#E2E8F0` (Card outlines, cell boundaries, dividers)
  - Text Primary: `#0F172A` (Headlines, values, critical labels)
  - Text Muted: `#64748B` (Secondary descriptions, timestamps, metadata)

### Functional Semantic Palette
Functional colors are subdued, avoiding electric or saturated hues to maintain visual tranquility:
- **Online / Safe:** `#15803D` (Text/Indicator), `#DCFCE7` (Background container)
- **Warning / Review Needed:** `#B45309` (Text/Indicator), `#FEF3C7` (Background container)
- **Critical / Urgent Alert:** `#B91C1C` (Text/Indicator), `#FEE2E2` (Background container)
- **Inactive / Paused:** `#64748B` (Text/Indicator), `#F1F5F9` (Background container)

## Typography

Typography relies uniformly on the canonical neutral sans-serif `Inter`. Hierarchy is established through weight distinctions (400 Regular, 500 Medium, 600 Semi-Bold) and tight line spacing rather than extreme scale variations.

### Typographic Guidelines
- **Numbers and Telemetry:** For screen time allocations, IP addresses, and activity timestamps, apply tabular lining numbers (`font-variant-numeric: tabular-nums`) to maintain alignment across list stacks.
- **Heading Restraint:** Never use all-caps for headings or lengthy copy. All-caps is reserved exclusively for `label-sm` badges and status pills with letter-spacing tracking (`0.04em`).
- **Body Rhythm:** Body text remains uncrowded with an optimal reading measure between 45 and 75 characters per line on informational and rule-setting panels.

## Layout & Spacing

The layout is built upon an 8px spatial grid with an underlying 4px baseline sub-grid. Dashboard screens implement a structured responsive layout model that balances scannability with comfortable breathing room.

### Responsive Breakpoints & Grid Structure
- **Mobile (<768px):** 4-column layout. Margin: `1rem` (16px), Gutter: `0.75rem` (12px). Top-level cards span the full canvas width; telemetry indicators stack vertically.
- **Tablet (768px - 1024px):** 8-column layout. Margin: `1.5rem` (24px), Gutter: `1rem` (16px). Secondary sidebar collapses to an icon utility rail or drawer.
- **Desktop (>1024px):** 12-column layout. Maximum content container width capped at `1440px`. Margin: `2rem` (32px), Gutter: `1.25rem` (20px). Persistent 260px administrative sidebar.

### Layout Principles
- **Grouping Over Separation:** Use background surface transitions (`#F1F5F9` on `#FFFFFF`) or hairline rules (`#E2E8F0`) before resorting to heavy spacing.
- **Card Interior Padding:** Standard dashboard cards enforce `space-lg` (1.5rem) on desktop and `space-md` (1rem) on compact screens to maintain unified density.

## Elevation & Depth

Visual hierarchy is communicated through structural layering and razor-sharp, low-contrast hairline outlines rather than dramatic elevation tiers. This keeps cognitive load low and preserves the clinical clarity of a parental oversight system.

### Elevation Tiers
- **Tier 0 (Base Canvas):** Background tone `#F8F9FA`. Un-elevated, structural baseline.
- **Tier 1 (Cards, Modules & Panels):** Solid `#FFFFFF` fill with a `1px solid #E2E8F0` border and micro-elevation: `box-shadow: 0 1px 2px 0 rgba(15, 23, 42, 0.05)`.
- **Tier 2 (Dropdowns, Menus & Tooltips):** Solid `#FFFFFF` fill with `1px solid #E2E8F0` and subtle elevation: `box-shadow: 0 4px 6px -1px rgba(15, 23, 42, 0.08), 0 2px 4px -2px rgba(15, 23, 42, 0.05)`.
- **Tier 3 (Modal Overlays & Urgent Safety Dialogs):** Solid `#FFFFFF` fill, `1px solid #CBD5E1`, elevated with `box-shadow: 0 10px 15px -3px rgba(15, 23, 42, 0.1), 0 4px 6px -4px rgba(15, 23, 42, 0.05)`. The underlying backdrop uses a flat slate scrim: `rgba(15, 23, 42, 0.4)`.

Shadows are consistently tinted with cool slate (`rgba(15, 23, 42, ...)`) instead of harsh pure black.

## Shapes

The system uses a soft, disciplined geometry. Corners are rounded just enough to remove harshness without turning playful or bulbous.

### Token Mapping
- **Default (`rounded`):** `0.25rem` (4px). Applied to table cell badges, input fields, checkboxes, toggle buttons, and micro-indicators.
- **Large (`rounded-lg`):** `0.5rem` (8px). Standard corner radius for primary content cards, modal dialogs, flyout sheets, and interactive button groups.
- **Extra Large (`rounded-xl`):** `0.75rem` (12px). Applied strictly to major sectional parent cards or full-screen dashboard summary banners.

Pill shapes and round geometric motifs are prohibited, except for circular 1:1 user profile avatars and status indicator dots.

## Components

### Buttons
- **Primary:** Solid `#1E4E5F` background, `#FFFFFF` text, `0.5rem` radius, `0.5rem 1rem` padding. Subtle hover state to `#173E4C`. Active state `#122E3A`.
- **Secondary / Outline:** `#FFFFFF` background, `1px solid #CBD5E1` border, `#0F172A` text. Hover: `#F8F9FA` with border tint `#94A3B8`.
- **Destructive / Urgent Block:** `#B91C1C` background, `#FFFFFF` text. Used exclusively for revoking device access, wiping device records, or critical incident lockdown.

### Status Badges & Chips
- Restrained rectangular micro-tags with `0.25rem` radius, `0.125rem 0.5rem` padding, `0.75rem` font size (`label-sm`), and uppercase letter-spacing.
- Pairs a 6px solid circular dot with muted container colors:
  - Active: Green dot (`#15803D`) on `#DCFCE7` container, text `#14532D`.
  - Caution: Amber dot (`#B45309`) on `#FEF3C7` container, text `#78350F`.
  - Offline: Slate dot (`#64748B`) on `#F1F5F9` container, text `#334155`.

### Input Fields & Controls
- Standard height: 40px (Desktop), 44px (Mobile).
- Background: `#FFFFFF`, Border: `1px solid #CBD5E1`, Radius: `0.375rem`.
- Focus ring: `2px solid #1E4E5F` with an outer soft offset `2px rgba(30, 78, 95, 0.15)`. No default browser blue rings.

### Checkboxes & Toggle Switches
- **Toggles (Device Bedtime / Web Protection):** Track width 36px, height 20px, `rounded-full`. Inactive track `#CBD5E1`; Active track `#1E4E5F`. Thumb is white `#FFFFFF` with standard 1px box shadow.
- **Checkboxes:** 16px × 16px, `0.25rem` radius, `1px solid #94A3B8`. Checked fill `#1E4E5F` with white checkmark.

### Cards & Telemetry Containers
- Background `#FFFFFF`, border `1px solid #E2E8F0`, corner radius `0.5rem`.
- Card headers feature clear divider lines (`border-bottom: 1px solid #F1F5F9`) separating the title and control icon from metrics data.

### Activity Table & Log Rows
- Clean, borders-only table rows with minimal hover highlighting (`#F8F9FA`).
- Column headers: `0.75rem` (`label-sm`), uppercase, `#64748B`, with bottom border `1px solid #E2E8F0`.
- Data rows: 48px height to provide spacious, scannable reading for timestamps, application names, and domain access status.